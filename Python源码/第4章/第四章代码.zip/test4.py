#列表基本操作
# list1=["python",25,"周杰伦"]
# print(list1[:2])
# list_one = ['章萍', '李昊', '武田', '李彪']
# for i in list_one:
#     print(f"嗨，{i}！今日促销,赶快来抢购吧！")
# list_one = [1, 2, 3, 4,4,4,4,4]
# list_one.append(5)
# list_one.insert(1,6)
#
# del list_one[0]
# list_one.remove(3)
# list_one[0]=10
# print(list_one)

# 有一个列表，内容是：[21, 25, 21, 23, 22, 20]，记录的是一批学生的年龄
#
# 请通过列表的功能（方法），对其进行
# 定义这个列表，并用变量接收它
# 追加一个数字31，到列表的尾部
# 打印第一个元素（应是：21）
# 更新倒数第二个元素为26

# 在列表的第4个位置插入19
a=[21, 25, 21, 23, 22, 20]
a.append(31)
print(a[0])
a[-2]=26
a.insert(3,19)
print(a)
