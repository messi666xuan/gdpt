# greeting.py

def say_hello(name):
    print(f"你好, {name}！")

if __name__ == "__main__":
    print("这是 main 程序在 greetings.py")
    say_hello("小明")
# print("这是 main 程序在 greeting.py")
# say_hello("小明")